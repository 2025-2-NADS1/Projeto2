﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EXEMPLO_02_SERVER
{
    class Program
    {
        /* GET TIME
         * GET TIME LONDON
           GET DATE 
           SET SUMMERTIME {TRUE|FALSE}
           */
        static TcpListener tcpServer;
        static string myIP;
        static bool fim;
        static bool summerTime;
        static int numAsk = -1;
        static void Main(string[] args)
        {
            fim = false;
            summerTime = false;
            myIP = "127.0.0.1";
            tcpServer = new TcpListener(IPAddress.Parse(myIP), 30000);
            tcpServer.Start();
            Thread threadServer = new Thread(() => serverListener());
            threadServer.Start();
            //TcpClient client = new TcpClient();
            //client.Connect(myIP, 80);
            Console.WriteLine("Pressione [ENTER] para terninar...");
            Console.ReadLine();
            fim = true;
        }

        public static void serverListener()
        {
            while (!fim)
            {
                TcpClient client = tcpServer.AcceptTcpClient();
                Thread thread = new Thread(() => responseMessage(client));
                thread.Start();
            }

        }

        public static void responseMessage(TcpClient client)
        {
            Console.WriteLine(client.Client.RemoteEndPoint);
            String msg = receiveTCPMessage(client);
            Console.WriteLine(msg);
            msg = parseMsg(msg);
            sendTCPMessage(client, msg);
        }

        private static string parseMsg(string msg)
        {
            String[] parse = msg.Split(' ');
            String resposta = "Comando Desconhecido!!";
            string[] perguntas = { "DICA 1: Grão fortemente comercializado durante as imigrações no Brasil",
                                    "DICA 2: Massa etnica de maior numero durante as imigrações",
                                    "DICA 3: O bairro da liberdade tem muitas pessoas vinda de onde?",};
            string[] gabarito = { "CAFE", "ITALIA", "JAPAO", };

            if (parse[0] == "DICA")

            {
                int dica = int.Parse(parse[1]);
                dica = dica - 1;
                if (dica >= 0 && dica < 3)
                {
                    resposta = perguntas[dica];
                    numAsk = dica;
                }
                else
                {
                    resposta = "ERRO";
                }
                if (parse[0] == "RESPOSTA")
                    if (parse[1] == gabarito[numAsk])
                    {
                        resposta = "A PALAVRA ESTÁ CORRETA!";
                    }
                    else
                    {
                        resposta = "A PALAVRA ESTÁ ERRADA!";
                    }
                if (parse[0] == "DICA")
                {
                    if (parse[1] == "PERGUNTA") { }

                }
                return resposta;
            }
        }
    
        public static string receiveTCPMessage(TcpClient tcpClient)
        {
            string TCPMsg = "";
            int i;

            NetworkStream stream = tcpClient.GetStream();
            string ip = tcpClient.Client.RemoteEndPoint.ToString();
            ip = ip.Substring(0, ip.IndexOf(':'));

            Byte[] byteMsg = new Byte[tcpClient.ReceiveBufferSize];
            //TCPMsg = ip + " falou:>>";
            int tentativa = 0;
            while (!stream.DataAvailable && tentativa < 10)
            {
                Thread.Sleep(50);
                tentativa++;
            }

            while (stream.DataAvailable)
            {
                i = stream.Read(byteMsg, 0, byteMsg.Length);
                TCPMsg = TCPMsg + System.Text.Encoding.ASCII.GetString(byteMsg, 0, i);
            }

            return TCPMsg;
        }

        public static void sendTCPMessage(TcpClient tcpClient, String msg)
        {

            NetworkStream stream = tcpClient.GetStream();
            Byte[] byteMsg = System.Text.Encoding.UTF8.GetBytes(msg);
            if (stream.CanWrite)
            {
                stream.Write(byteMsg, 0, byteMsg.Length);
                stream.Flush();
            }
            else
            {
                throw new Exception("Problema de Comunicação!!!.");
            }

            tcpClient.Close();
        }

    }


}
