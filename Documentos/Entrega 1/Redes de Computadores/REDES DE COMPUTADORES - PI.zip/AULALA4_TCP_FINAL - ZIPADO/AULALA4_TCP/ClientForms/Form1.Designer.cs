﻿namespace ClientForms
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtComando = new TextBox();
            txtResposta = new TextBox();
            btnEnviar = new Button();
            btnLimpar = new Button();
            SuspendLayout();
            // 
            // txtComando
            // 
            txtComando.Location = new Point(1, 1);
            txtComando.Name = "txtComando";
            txtComando.Size = new Size(493, 23);
            txtComando.TabIndex = 0;
            // 
            // txtResposta
            // 
            txtResposta.BackColor = SystemColors.InfoText;
            txtResposta.Font = new Font("Courier New", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtResposta.ForeColor = Color.Lime;
            txtResposta.Location = new Point(1, 53);
            txtResposta.Multiline = true;
            txtResposta.Name = "txtResposta";
            txtResposta.Size = new Size(880, 367);
            txtResposta.TabIndex = 1;
            // 
            // btnEnviar
            // 
            btnEnviar.Location = new Point(500, 1);
            btnEnviar.Name = "btnEnviar";
            btnEnviar.Size = new Size(75, 23);
            btnEnviar.TabIndex = 2;
            btnEnviar.Text = "Enviar";
            btnEnviar.UseVisualStyleBackColor = true;
            btnEnviar.Click += btnEnviar_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(806, 426);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(75, 23);
            btnLimpar.TabIndex = 3;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(991, 474);
            Controls.Add(btnLimpar);
            Controls.Add(btnEnviar);
            Controls.Add(txtResposta);
            Controls.Add(txtComando);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtComando;
        private TextBox txtResposta;
        private Button btnEnviar;
        private Button btnLimpar;
    }
}
